[METHOD: mut_123caca9 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner BLU
add_edge LD
add_edge BU
add_edge RU
add_edge BR
add_edge BD
add_edge FU
add_edge FU
[STEP: step_1 | cache_alg=false]
add_corner BRD
add_edge FD
add_corner FRU
add_edge FR
add_edge BL
[STEP: step_2 | cache_alg=false]
add_corner BLD
add_corner FLD
add_corner FRD
add_edge FL
add_edge LU
add_corner FLU
add_corner BRU
[END METHOD]