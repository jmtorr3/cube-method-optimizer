[METHOD: mut_2bda2b37 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge BD
add_corner FRU
add_corner FLD
add_corner BLD
add_edge FD
add_edge LD
[STEP: step_1 | cache_alg=false]
add_edge BU
add_edge BR
add_edge FU
add_corner BRD
add_corner FLU
add_corner FRD
[STEP: step_2 | cache_alg=false]
add_corner BRU
add_corner BLU
add_edge LU
add_edge FR
[STEP: step_3 | cache_alg=false]
add_edge BL
add_edge RD
add_edge RU
add_edge FL
[END METHOD]