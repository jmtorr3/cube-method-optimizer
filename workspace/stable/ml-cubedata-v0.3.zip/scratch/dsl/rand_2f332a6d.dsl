[METHOD: rand_2f332a6d | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner FLD
add_edge FD
add_edge BL
add_edge FL
[STEP: step_1 | cache_alg=false]
add_corner FLU
add_edge BU
add_edge FR
[STEP: step_2 | cache_alg=false]
add_edge BR
add_edge RU
add_corner BRD
add_corner BLU
add_edge BD
add_edge RD
[STEP: step_3 | cache_alg=false]
add_corner BLD
add_corner FRU
add_edge LU
[STEP: step_4 | cache_alg=false]
add_corner FRD
add_corner BRU
add_edge FU
add_edge LD
[END METHOD]