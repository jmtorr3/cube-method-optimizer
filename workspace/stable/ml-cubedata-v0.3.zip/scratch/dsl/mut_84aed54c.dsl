[METHOD: mut_84aed54c | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge BU
add_edge FD
add_corner FRD
add_edge FL
add_edge RU
add_corner FRD
add_corner BRD
add_corner FLU
[STEP: step_1 | cache_alg=false]
add_edge FU
add_edge LD
add_edge LU
add_corner FRU
add_corner FLD
[STEP: step_2 | cache_alg=false]
add_edge BL
add_edge RD
add_corner BLD
add_edge BD
[STEP: step_3 | cache_alg=false]
add_corner BLU
add_edge FR
add_corner BRU
[END METHOD]