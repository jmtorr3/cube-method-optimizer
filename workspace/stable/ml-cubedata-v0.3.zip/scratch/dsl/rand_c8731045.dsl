[METHOD: rand_c8731045 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner FRU
add_corner BLD
add_edge FL
add_corner BRD
[STEP: step_1 | cache_alg=false]
add_edge FR
add_edge RD
add_edge BU
add_corner BLU
add_corner FRD
[STEP: step_2 | cache_alg=false]
add_corner BRU
add_edge LD
add_edge BD
add_edge BR
add_edge FU
add_corner FLU
add_edge RU
add_edge LU
[STEP: step_3 | cache_alg=false]
add_edge FD
add_edge BL
add_corner FLD
[END METHOD]