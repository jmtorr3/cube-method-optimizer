[METHOD: rand_71a3258a | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge LU
add_corner FLU
add_edge BR
add_corner BLD
[STEP: step_1 | cache_alg=false]
add_edge FU
add_edge BL
add_edge BU
add_corner FLD
add_corner BRU
add_edge FR
add_edge FD
[STEP: step_2 | cache_alg=false]
add_edge LD
add_corner FRU
add_edge BD
[STEP: step_3 | cache_alg=false]
add_edge RD
add_edge RU
add_corner BRD
[STEP: step_4 | cache_alg=false]
add_corner FRD
add_edge FL
add_corner BLU
[END METHOD]