[METHOD: rand_559e3cc7 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner FRD
add_edge BU
add_corner BLD
add_edge RD
add_edge FU
[STEP: step_1 | cache_alg=false]
add_edge BD
add_edge LU
add_corner FRU
add_edge BR
add_corner FLU
add_corner BRU
[STEP: step_2 | cache_alg=false]
add_edge FD
add_corner BLU
add_edge LD
[STEP: step_3 | cache_alg=false]
add_edge FR
add_edge FL
add_edge RU
add_edge BL
add_corner BRD
add_corner FLD
[END METHOD]