[METHOD: rand_5bf065aa | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner FRD
add_edge LD
add_edge BR
add_corner BLU
add_edge FD
add_edge RD
add_corner BRD
[STEP: step_1 | cache_alg=false]
add_edge BD
add_edge BU
add_edge FR
add_edge RU
add_edge BL
[STEP: step_2 | cache_alg=false]
add_corner FRU
add_edge FL
add_corner FLD
add_edge LU
[STEP: step_3 | cache_alg=false]
add_corner BLD
add_corner BRU
add_corner FLU
add_edge FU
[END METHOD]