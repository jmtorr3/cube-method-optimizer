[METHOD: mut_ca961b27 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner BRD
add_edge LU
add_edge BR
[STEP: step_1 | cache_alg=false]
add_corner FLU
add_edge RU
add_edge BD
add_edge FR
add_edge LD
[STEP: step_2 | cache_alg=false]
add_edge FU
add_corner FRD
add_corner FLD
add_corner BLU
add_edge FL
add_edge BL
add_corner FRU
[STEP: step_3 | cache_alg=false]
add_edge FD
add_corner BRU
add_corner BLD
add_edge RD
add_edge BU
[END METHOD]