[METHOD: rand_b57c9b4b | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner FRU
add_edge BD
add_edge BU
add_edge FD
add_corner FLD
add_corner BLU
add_edge FL
add_edge RU
[STEP: step_1 | cache_alg=false]
add_edge FR
add_edge BR
add_corner BRD
[STEP: step_2 | cache_alg=false]
add_corner FRD
add_edge LD
add_edge FU
add_edge BL
add_corner BRU
add_edge RD
[STEP: step_3 | cache_alg=false]
add_corner BLD
add_edge LU
add_corner FLU
[END METHOD]