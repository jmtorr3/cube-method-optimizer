[METHOD: mut_e6a21318 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge LD
add_corner FRU
add_edge BU
add_corner FLD
add_edge BD
add_corner BLU
add_edge BR
[STEP: step_1 | cache_alg=false]
add_edge RU
add_edge FD
add_edge FR
add_edge RU
add_edge FL
add_corner BLD
add_corner FLU
[STEP: step_2 | cache_alg=false]
add_corner BRD
add_edge BL
add_corner FLU
add_edge LU
add_edge FU
add_edge RD
[END METHOD]