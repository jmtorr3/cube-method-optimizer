[METHOD: rand_8fda85e2 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner FLU
add_edge LD
add_edge BL
add_edge LU
add_edge BD
add_corner FLD
add_edge BU
add_edge FR
[STEP: step_1 | cache_alg=false]
add_edge RD
add_edge BR
add_corner BLU
add_edge RU
add_corner BLD
[STEP: step_2 | cache_alg=false]
add_edge FD
add_corner FRD
add_edge FU
add_edge FL
[STEP: step_3 | cache_alg=false]
add_corner BRD
add_corner BRU
add_corner FRU
[END METHOD]