[METHOD: mut_d4664f1a | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner BRD
add_edge BD
add_edge BL
add_edge RD
add_corner BLD
add_corner FRD
add_edge BU
[STEP: step_1 | cache_alg=false]
add_corner FLD
add_edge FL
add_edge LD
[STEP: step_2 | cache_alg=false]
add_edge LU
add_corner BLU
add_corner FLU
add_edge FU
[STEP: step_3 | cache_alg=false]
add_edge BR
add_edge FD
add_corner BRU
[STEP: step_4 | cache_alg=false]
add_corner FRU
add_edge RU
add_edge FR
[END METHOD]