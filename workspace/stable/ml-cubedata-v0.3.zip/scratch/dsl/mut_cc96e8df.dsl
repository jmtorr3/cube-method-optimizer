[METHOD: mut_cc96e8df | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge BU
add_corner BRU
add_edge FU
add_edge BD
add_corner BRU
add_edge BR
add_edge BL
[STEP: step_1 | cache_alg=false]
add_corner BRD
add_edge LU
add_edge RU
add_edge LD
add_edge FR
add_edge FL
[STEP: step_2 | cache_alg=false]
add_corner BLU
add_corner BLD
add_edge FD
add_corner FLU
add_edge RD
add_corner FLD
add_corner FRU
[END METHOD]