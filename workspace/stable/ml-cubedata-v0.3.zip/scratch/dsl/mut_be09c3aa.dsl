[METHOD: mut_be09c3aa | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner FRU
add_edge LD
add_edge FD
add_edge BR
add_edge BU
[STEP: step_1 | cache_alg=false]
add_corner FLU
add_corner FRD
add_edge BD
add_corner BRD
add_corner BRU
add_edge FL
[STEP: step_2 | cache_alg=false]
add_corner BLU
add_edge LU
add_corner FLD
add_edge RU
add_edge BL
[STEP: step_3 | cache_alg=false]
add_edge FU
add_edge RD
add_edge FR
add_corner BLD
[END METHOD]