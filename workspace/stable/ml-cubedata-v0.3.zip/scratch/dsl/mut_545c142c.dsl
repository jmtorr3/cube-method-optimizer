[METHOD: mut_545c142c | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner FRD
add_edge RD
add_corner FLD
add_edge LD
add_corner BLD
add_edge BD
add_corner BRD
add_edge BL
[STEP: step_1 | cache_alg=false]
add_edge BL
add_edge FU
add_corner FLU
[STEP: step_2 | cache_alg=false]
add_corner FRU
add_edge BU
add_corner BLU
add_corner BRU
[STEP: step_3 | cache_alg=false]
add_edge FD
add_edge LU
add_edge FR
add_edge RU
add_edge FL
[END METHOD]