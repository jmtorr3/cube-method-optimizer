[METHOD: rand_e10459c4 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_corner FLU
add_edge BD
add_edge BL
add_edge RD
add_corner BLD
[STEP: step_1 | cache_alg=false]
add_corner FRU
add_corner BLU
add_edge LD
[STEP: step_2 | cache_alg=false]
add_edge LU
add_edge FL
add_corner BRD
add_edge FU
add_corner FRD
[STEP: step_3 | cache_alg=false]
add_edge BR
add_edge FD
add_corner BRU
[STEP: step_4 | cache_alg=false]
add_corner FLD
add_edge BU
add_edge RU
add_edge FR
[END METHOD]