[METHOD: mut_b4991af0 | rotation=x2]
[STEP: step_0 | cache_alg=false]
add_edge FU
add_corner FLD
add_edge BL
add_edge LU
[STEP: step_1 | cache_alg=false]
add_edge FL
add_corner BLU
add_corner BLD
add_corner BRD
add_edge LD
[STEP: step_2 | cache_alg=false]
add_corner BRU
add_edge FD
[STEP: step_3 | cache_alg=false]
add_edge BR
add_edge BD
add_edge RU
[STEP: step_4 | cache_alg=false]
add_corner FRD
add_edge RD
add_edge BU
add_edge FR
add_corner FRU
add_corner FLU
[END METHOD]